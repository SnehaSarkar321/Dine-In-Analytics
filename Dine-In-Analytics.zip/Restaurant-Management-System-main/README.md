# Restaurant-Management-System
The purpose of making this project is to help the restaurant industry streamline their food business operation. It provides a complete set of features including table reservation, accounting management, customer management etc.
